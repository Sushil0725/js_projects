// JavaScript to toggle password visibility and show/hide the eye icon
const passwordInput = document.getElementById("password");
const eyeIcon = document.getElementById("toggle-password");

// Event listener to toggle password visibility
eyeIcon.addEventListener("click", function() {
    const passwordType = passwordInput.type;
    const eyeIconElement = this.querySelector("i");

    if (passwordType === "password") {
        passwordInput.type = "text";
        eyeIconElement.classList.remove("far", "fa-eye");
        eyeIconElement.classList.add("far", "fa-eye-slash");
    } else {
        passwordInput.type = "password";
        eyeIconElement.classList.remove("far", "fa-eye-slash");
        eyeIconElement.classList.add("far", "fa-eye");
    }
});

// Event listener to show/hide the eye icon based on input content
passwordInput.addEventListener("input", function() {
    if (passwordInput.value.length > 0) {
        eyeIcon.style.display = "block";  // Show the eye icon when there's input
    } else {
        eyeIcon.style.display = "none";  // Hide the eye icon when the field is empty
    }
});
