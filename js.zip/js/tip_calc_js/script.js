document.getElementById('calculateBtn').addEventListener('click', calculateTip);
document.getElementById('resetBtn').addEventListener('click', resetCalculator);
document.getElementById('tipPercentage').addEventListener('change', toggleCustomTipInput);

function calculateTip() {
    const billAmount = parseFloat(document.getElementById('billAmount').value);
    let tipPercentage = document.getElementById('tipPercentage').value;
    let customTip = parseFloat(document.getElementById('customTip').value);

    if (tipPercentage === "custom" && !isNaN(customTip)) {
        tipPercentage = customTip;
    } else {
        tipPercentage = parseFloat(tipPercentage);
    }

    const tipAmount = (billAmount * tipPercentage) / 100;
    const totalAmount = billAmount + tipAmount;

    document.getElementById('tipAmount').innerText = `Tip Amount: $${tipAmount.toFixed(2)}`;
    document.getElementById('totalAmount').innerText = `Total Amount: $${totalAmount.toFixed(2)}`;
}

function resetCalculator() {
    document.getElementById('billAmount').value = '';
    document.getElementById('tipPercentage').value = '15';
    document.getElementById('customTip').value = '';
    document.getElementById('customTip').style.display = 'none';
    document.getElementById('customTipLabel').style.display = 'none';
    document.getElementById('tipAmount').innerText = `Tip Amount: $0.00`;
    document.getElementById('totalAmount').innerText = `Total Amount: $0.00`;
}

function toggleCustomTipInput() {
    const tipPercentage = document.getElementById('tipPercentage').value;
    const customTipInput = document.getElementById('customTip');
    const customTipLabel = document.getElementById('customTipLabel');

    if (tipPercentage === "custom") {
        customTipInput.style.display = 'block';
        customTipLabel.style.display = 'block';
    } else {
        customTipInput.style.display = 'none';
        customTipLabel.style.display = 'none';
    }
}
