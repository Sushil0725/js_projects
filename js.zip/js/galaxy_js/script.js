const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const spaceship = {
    x: canvas.width / 2 - 15,
    y: canvas.height - 50,
    width: 30,
    height: 30,
    color: 'cyan'
};

const bullets = [];
const asteroids = [];
let score = 0;
let gameOver = false;
let isPaused = false; // Variable to track pause state
const sideSpeed = 7; // Variable for player movement speed

const keys = {}; // Object to track key states

// Function to draw the spaceship
function drawSpaceship() {
    ctx.fillStyle = spaceship.color;
    ctx.fillRect(spaceship.x, spaceship.y, spaceship.width, spaceship.height);
}

// Function to draw bullets
function drawBullets() {
    bullets.forEach((bullet, index) => {
        ctx.fillStyle = 'yellow';
        ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
        bullet.y -= bullet.speed;

        // Remove bullet if it goes off-screen
        if (bullet.y + bullet.height < 0) {
            bullets.splice(index, 1);
        }
    });
}

// Function to draw asteroids
function drawAsteroids() {
    asteroids.forEach((asteroid, index) => {
        ctx.fillStyle = asteroid.color;
        ctx.fillRect(asteroid.x, asteroid.y, asteroid.width, asteroid.height);
        asteroid.y += asteroid.speed;

        // Check for collision between asteroid and spaceship
        if (checkCollision(spaceship, asteroid)) {
            endGame();
        }

        // Remove asteroid if it goes off-screen
        if (asteroid.y > canvas.height) {
            asteroids.splice(index, 1);
        }
    });
}

// Function to detect collisions between bullets and asteroids
function detectCollisions() {
    bullets.forEach((bullet, bulletIndex) => {
        asteroids.forEach((asteroid, asteroidIndex) => {
            if (checkCollision(bullet, asteroid)) {
                // Collision detected
                bullets.splice(bulletIndex, 1);
                asteroids.splice(asteroidIndex, 1);
                score += 10;
                updateScore();
            }
        });
    });
}

// Function to check for collision between two objects
function checkCollision(obj1, obj2) {
    return obj1.x < obj2.x + obj2.width &&
           obj1.x + obj1.width > obj2.x &&
           obj1.y < obj2.y + obj2.height &&
           obj1.y + obj1.height > obj2.y;
}

// Function to update the score display
function updateScore() {
    document.getElementById('scoreboard').innerText = `Score: ${score}`;
}

// Function to end the game
function endGame() {
    gameOver = true;
    document.getElementById('replayButton').style.display = 'block';
}

// Function to reset the game
function resetGame() {
    spaceship.x = canvas.width / 2 - 15;
    bullets.length = 0;
    asteroids.length = 0;
    score = 0;
    gameOver = false;
    isPaused = false; // Ensure game is not paused after reset
    updateScore();
    document.getElementById('replayButton').style.display = 'none';
    generateAsteroids(); // Restart asteroid generation
    requestAnimationFrame(update);
}

// Function to handle game updates
function update() {
    if (gameOver || isPaused) return; // Skip updates if game is over or paused

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    handleKeys(); // Handle key states

    drawSpaceship();
    drawBullets();
    drawAsteroids();
    detectCollisions();

    requestAnimationFrame(update);
}

// Function to handle key states
function handleKeys() {
    if (keys['ArrowLeft'] && spaceship.x > 0) {
        spaceship.x -= sideSpeed;
    }
    if (keys['ArrowRight'] && spaceship.x + spaceship.width < canvas.width) {
        spaceship.x += sideSpeed;
    }
    if (keys[' ']) {
        // Shoot bullet
        fireBullet();
    }
}

// Function to fire bullets
function fireBullet() {
    if (bullets.length === 0 || bullets[bullets.length - 1].y < spaceship.y - 20) {
        // Prevent spamming bullets too quickly
        bullets.push({ x: spaceship.x + spaceship.width / 2 - 2.5, y: spaceship.y, width: 5, height: 10, speed: 5 });
    }
}

// Function to generate random asteroids
function generateAsteroids() {
    if (gameOver) return;

    const size = Math.random() * 30 + 20;
    const speed = Math.random() * 2 + 1;
    asteroids.push({ x: Math.random() * (canvas.width - size), y: -size, width: size, height: size, speed: speed, color: 'gray' });

    // Use setTimeout to ensure continuous asteroid generation
    setTimeout(generateAsteroids, 1000);
}

// Event listeners for keydown and keyup
window.addEventListener('keydown', (event) => {
    if (gameOver) return;
    keys[event.key] = true;

    if (event.key === 'x' || event.key === 'x') {
        isPaused = !isPaused; // Toggle pause state
        if (!isPaused) {
            update(); // Resume the game if unpaused
        }
    }
});

window.addEventListener('keyup', (event) => {
    keys[event.key] = false;
});

// Start game on load
document.getElementById('replayButton').addEventListener('click', resetGame);

// Initial function calls
generateAsteroids();
update();
