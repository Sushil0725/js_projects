// Function to handle form submission
document.getElementById('userForm')?.addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent form submission

    // Get form values
    const name = document.getElementById('name').value;
    const date = document.getElementById('date').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const gender = document.getElementById('gender').value;
    const age = document.getElementById('age').value;

    // Create user object
    const user = {
        name,
        date,
        email,
        phone,
        gender,
        age
    };

    // Store user data in local storage
    let users = JSON.parse(localStorage.getItem('users')) || [];
    users.push(user);
    localStorage.setItem('users', JSON.stringify(users));

    // Redirect to storage page
    window.location.href = 'storage.html';
});

// Function to load data into the table on storage page
window.onload = function () {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const tableBody = document.getElementById('dataTable').querySelector('tbody');

    // Populate the table with user data
    users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${user.name}</td>
            <td>${user.date}</td>
            <td>${user.email}</td>
            <td>${user.phone}</td>
            <td>${user.gender}</td>
            <td>${user.age}</td>
        `;
        tableBody.appendChild(row);
    });
};
