let flashcards = [];
let currentCardIndex = 0;
let showAnswer = false;

// Function to render the current flashcard
function renderFlashcard() {
  const flashcardContent = document.getElementById('flashcard-content');
  if (flashcards.length === 0) {
    flashcardContent.innerHTML = "No flashcards available. Add one!";
    return;
  }

  const currentCard = flashcards[currentCardIndex];
  flashcardContent.innerHTML = showAnswer ? currentCard.answer : currentCard.question;
}

// Function to flip the flashcard
function flipCard() {
  showAnswer = !showAnswer;
  renderFlashcard();
}

// Function to move to the next flashcard
function nextCard() {
  if (flashcards.length === 0) return;
  currentCardIndex = (currentCardIndex + 1) % flashcards.length;
  showAnswer = false;
  renderFlashcard();
}

// Function to move to the previous flashcard
function prevCard() {
  if (flashcards.length === 0) return;
  currentCardIndex = (currentCardIndex - 1 + flashcards.length) % flashcards.length;
  showAnswer = false;
  renderFlashcard();
}

// Function to add a new flashcard
function addCard(event) {
  event.preventDefault();
  
  const questionInput = document.getElementById('question');
  const answerInput = document.getElementById('answer');

  const newCard = {
    question: questionInput.value,
    answer: answerInput.value
  };

  flashcards.push(newCard);
  questionInput.value = "";
  answerInput.value = "";
  
  if (flashcards.length === 1) {
    currentCardIndex = 0;
    renderFlashcard();
  }
}

// Add event listener to the form for adding new flashcards
document.getElementById('addCardForm').addEventListener('submit', addCard);

// Render the initial state of the flashcard
renderFlashcard();
