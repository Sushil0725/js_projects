// Timer Logic
let countdownTime = 59 * 60 + 59; // Initial time (59:59)
let timerInterval;
const timerDisplay = document.getElementById("timer");

function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function updateTimerDisplay() {
  timerDisplay.textContent = formatTime(countdownTime);
}

function startCountdown() {
  if (timerInterval) return; // Prevent multiple intervals
  timerInterval = setInterval(() => {
    if (countdownTime <= 0) {
      clearInterval(timerInterval);
      timerInterval = null;
    } else {
      countdownTime--;
      updateTimerDisplay();
    }
  }, 1000);
}

function pauseCountdown() {
  clearInterval(timerInterval);
  timerInterval = null;
}

function resetCountdown() {
  clearInterval(timerInterval);
  timerInterval = null;
  countdownTime = 59 * 60 + 59; // Reset to initial value
  updateTimerDisplay();
}



// Update display initially
updateTimerDisplay();

// Floating Menu Logic
const floatingButton = document.querySelector(".floating-button");
const menuOptions = document.querySelector(".menu-options");
let isDragging = false,
  offsetX = 0,
  offsetY = 0,
  isMenuOpen = false;

const clamp = (value, min, max) => Math.max(min, Math.min(value, max));

// Handle drag start
const startDrag = (e) => {
  isDragging = true;
  const touch = e.touches ? e.touches[0] : e;
  offsetX = touch.clientX - floatingButton.offsetLeft;
  offsetY = touch.clientY - floatingButton.offsetTop;
  floatingButton.style.transition = "none";
};

// Handle drag move
const moveDrag = (e) => {
  if (!isDragging) return;
  const touch = e.touches ? e.touches[0] : e;
  floatingButton.style.left = `${clamp(touch.clientX - offsetX, 0, window.innerWidth - floatingButton.offsetWidth)}px`;
  floatingButton.style.top = `${clamp(touch.clientY - offsetY, 0, window.innerHeight - floatingButton.offsetHeight)}px`;
};

// Handle drag end
const endDrag = () => {
  isDragging = false;
  floatingButton.style.transition = "0.3s ease";
};

// Handle menu toggle
floatingButton.addEventListener("click", () => {
  isMenuOpen = !isMenuOpen;
  const { top, bottom, left, height } = floatingButton.getBoundingClientRect();
  menuOptions.style.left = `${left}px`;
  menuOptions.style.top = top < window.innerHeight / 2
    ? `${bottom}px`
    : `${top - menuOptions.offsetHeight}px`;
  menuOptions.classList.toggle("hidden", !isMenuOpen);
});

// Attach mouse events
floatingButton.addEventListener("mousedown", startDrag);
document.addEventListener("mousemove", moveDrag);
document.addEventListener("mouseup", endDrag);

// Attach touch events for mobile
floatingButton.addEventListener("touchstart", startDrag);
document.addEventListener("touchmove", moveDrag);
document.addEventListener("touchend", endDrag);
