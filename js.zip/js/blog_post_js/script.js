const form = document.getElementById('blog-form');
const postsContainer = document.getElementById('posts-container');

let posts = []; // Array to hold blog posts

form.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting

    const titleInput = document.getElementById('title');
    const contentInput = document.getElementById('content');

    const post = {
        id: Date.now(), // Unique ID for each post
        title: titleInput.value,
        content: contentInput.value
    };

    posts.push(post);
    titleInput.value = '';
    contentInput.value = '';
    renderPosts();
});

function renderPosts() {
    postsContainer.innerHTML = ''; // Clear current posts
    posts.forEach(post => {
        const postDiv = document.createElement('div');
        postDiv.className = 'post';
        postDiv.innerHTML = `
            <h2>${post.title}</h2>
            <p>${post.content}</p>
            <button onclick="editPost(${post.id})">Edit</button>
            <button onclick="deletePost(${post.id})">Delete</button>
        `;
        postsContainer.appendChild(postDiv);
    });
}

function editPost(postId) {
    const postIndex = posts.findIndex(post => post.id === postId);
    if (postIndex >= 0) {
        const post = posts[postIndex];
        document.getElementById('title').value = post.title;
        document.getElementById('content').value = post.content;
        posts.splice(postIndex, 1); // Remove the post from the array
        renderPosts(); // Update the post list
    }
}

function deletePost(postId) {
    posts = posts.filter(post => post.id !== postId); // Remove the post from the array
    renderPosts(); // Update the post list
}
