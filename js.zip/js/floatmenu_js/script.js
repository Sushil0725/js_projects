const floatingButton = document.querySelector(".floating-button");
const menuOptions = document.querySelector(".menu-options");
let isDragging = false, offsetX = 0, offsetY = 0, isMenuOpen = false;

const clamp = (value, min, max) => Math.max(min, Math.min(value, max));

// Handle drag start
const startDrag = (e) => {
    isDragging = true;
    const touch = e.touches ? e.touches[0] : e;
    offsetX = touch.clientX - floatingButton.offsetLeft;
    offsetY = touch.clientY - floatingButton.offsetTop;
    floatingButton.style.transition = "none";
};

// Handle drag move
const moveDrag = (e) => {
    if (!isDragging) return;
    const touch = e.touches ? e.touches[0] : e;
    floatingButton.style.left = `${clamp(touch.clientX - offsetX, 0, window.innerWidth - floatingButton.offsetWidth)}px`;
    floatingButton.style.top = `${clamp(touch.clientY - offsetY, 0, window.innerHeight - floatingButton.offsetHeight)}px`;
};

// Handle drag end
const endDrag = () => {
    isDragging = false;
    floatingButton.style.transition = "0.3s ease";
};

// Handle menu toggle
floatingButton.addEventListener("click", () => {
    isMenuOpen = !isMenuOpen;
    const { top, bottom, left, height } = floatingButton.getBoundingClientRect();
    menuOptions.style.left = `${left}px`;
    menuOptions.style.top = top < window.innerHeight / 2
        ? `${bottom}px`
        : `${top - menuOptions.offsetHeight}px`;
    menuOptions.classList.toggle("hidden", !isMenuOpen);
});

// Attach mouse events
floatingButton.addEventListener("mousedown", startDrag);
document.addEventListener("mousemove", moveDrag);
document.addEventListener("mouseup", endDrag);

// Attach touch events for mobile
floatingButton.addEventListener("touchstart", startDrag);
document.addEventListener("touchmove", moveDrag);
document.addEventListener("touchend", endDrag);
