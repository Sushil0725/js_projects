const rows = 6;
const columns = 7;
let currentPlayer = "player1";
let board = Array.from({ length: rows }, () => Array(columns).fill(null));
const grid = document.getElementById("grid");
const turnDisplay = document.getElementById("turnDisplay");
const resetButton = document.getElementById("resetButton");

// Initialize the grid
function initializeGrid() {
  grid.innerHTML = "";
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < columns; col++) {
      const cell = document.createElement("div");
      cell.classList.add("cell");
      cell.dataset.row = row;
      cell.dataset.col = col;
      cell.addEventListener("click", handleCellClick);
      grid.appendChild(cell);
    }
  }
}

// Handle cell click to place a disc
function handleCellClick(event) {
  const col = parseInt(event.currentTarget.dataset.col);

  // Find the lowest available row in the column
  let row = rows - 1;
  while (row >= 0 && board[row][col] !== null) {
    row--;
  }

  if (row >= 0) {
    board[row][col] = currentPlayer;
    const cell = document.querySelector(`.cell[data-row='${row}'][data-col='${col}']`);
    cell.classList.add(currentPlayer);

    if (checkWin(row, col)) {
      turnDisplay.textContent = `Player ${currentPlayer === "player1" ? 1 : 2} Wins!`;
      disableGrid();
      return;
    }

    // Toggle players and update turn display
    currentPlayer = currentPlayer === "player1" ? "player2" : "player1";
    turnDisplay.textContent = `Turn: Player ${currentPlayer === "player1" ? 1 : 2}`;
  }
}

// Check for win conditions
function checkWin(row, col) {
  return checkDirection(row, col, 1, 0) ||  // Horizontal
         checkDirection(row, col, 0, 1) ||  // Vertical
         checkDirection(row, col, 1, 1) ||  // Diagonal down-right
         checkDirection(row, col, 1, -1);   // Diagonal up-right
}

// Check a specific direction for four consecutive pieces
function checkDirection(row, col, rowOffset, colOffset) {
  let count = 1;
  count += countDirection(row, col, rowOffset, colOffset);
  count += countDirection(row, col, -rowOffset, -colOffset);
  return count >= 4;
}

// Helper function to count consecutive pieces in a direction
function countDirection(row, col, rowOffset, colOffset) {
  let count = 0;
  let r = row + rowOffset;
  let c = col + colOffset;
  while (r >= 0 && r < rows && c >= 0 && c < columns && board[r][c] === currentPlayer) {
    count++;
    r += rowOffset;
    c += colOffset;
  }
  return count;
}

// Disable further clicks on the grid after a win
function disableGrid() {
  for (const cell of document.querySelectorAll(".cell")) {
    cell.removeEventListener("click", handleCellClick);
  }
}

// Reset the game
function resetGame() {
  board = Array.from({ length: rows }, () => Array(columns).fill(null));
  currentPlayer = "player1";
  turnDisplay.textContent = "Turn: Player 1";
  initializeGrid();
}

// Add reset button functionality
resetButton.addEventListener("click", resetGame);

// Start the game
initializeGrid();
