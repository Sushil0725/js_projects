#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a structure to hold student information
struct Student {
    char name[50];
    int rollNo;
    float marks;
};

// Function to add a new student
void addStudent() {
    FILE *file = fopen("students.txt", "ab");
    struct Student student;

    if (file == NULL) {
        printf("Error opening file!\n");
        return;
    }

    printf("Enter student name: ");
    getchar(); // to consume the newline character
    fgets(student.name, sizeof(student.name), stdin);
    student.name[strcspn(student.name, "\n")] = '\0'; // Remove newline character from string

    printf("Enter roll number: ");
    scanf("%d", &student.rollNo);

    printf("Enter marks: ");
    scanf("%f", &student.marks);

    fwrite(&student, sizeof(student), 1, file);
    fclose(file);
    printf("Student added successfully!\n");
}

// Function to display all students
void displayStudents() {
    FILE *file = fopen("students.txt", "rb");
    struct Student student;

    if (file == NULL) {
        printf("No students found!\n");
        return;
    }

    printf("\nList of students:\n");
    printf("------------------------------------------------\n");
    printf("| Roll No | Name               | Marks         |\n");
    printf("------------------------------------------------\n");
    while (fread(&student, sizeof(student), 1, file)) {
        printf("| %-8d| %-18s| %-13.2f|\n", student.rollNo, student.name, student.marks);
    }
    printf("------------------------------------------------\n");
    fclose(file);
}

// Function to search for a student by roll number
void searchStudent() {
    FILE *file = fopen("students.txt", "rb");
    struct Student student;
    int rollNo;
    int found = 0;

    if (file == NULL) {
        printf("No students found!\n");
        return;
    }

    printf("Enter roll number to search: ");
    scanf("%d", &rollNo);

    while (fread(&student, sizeof(student), 1, file)) {
        if (student.rollNo == rollNo) {
            printf("\nStudent found:\n");
            printf("Name: %s\n", student.name);
            printf("Roll Number: %d\n", student.rollNo);
            printf("Marks: %.2f\n", student.marks);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Student with roll number %d not found!\n", rollNo);
    }

    fclose(file);
}

// Function to delete a student by roll number
void deleteStudent() {
    FILE *file = fopen("students.txt", "rb");
    FILE *tempFile = fopen("temp.txt", "wb");
    struct Student student;
    int rollNo;
    int found = 0;

    if (file == NULL || tempFile == NULL) {
        printf("Error opening file!\n");
        return;
    }

    printf("Enter roll number to delete: ");
    scanf("%d", &rollNo);

    while (fread(&student, sizeof(student), 1, file)) {
        if (student.rollNo == rollNo) {
            printf("Student with roll number %d deleted successfully!\n", rollNo);
            found = 1;
        } else {
            fwrite(&student, sizeof(student), 1, tempFile);
        }
    }

    if (!found) {
        printf("Student with roll number %d not found!\n", rollNo);
    }

    fclose(file);
    fclose(tempFile);

    // Remove the original file and rename temp file to original file
    remove("students.txt");
    rename("temp.txt", "students.txt");
}

int main() {
    int choice;

    while (1) {
        printf("\nStudent Management System\n");
        printf("1. Add Student\n");
        printf("2. Display Students\n");
        printf("3. Search Student by Roll Number\n");
        printf("4. Delete Student by Roll Number\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                displayStudents();
                break;
            case 3:
                searchStudent();
                break;
            case 4:
                deleteStudent();
                break;
            case 5:
                exit(0);
                break;
            default:
                printf("Invalid choice! Please enter a valid option.\n");
        }
    }

    return 0;
}
