// Get elements from the DOM
const taskInput = document.getElementById('new-task');
const addTaskButton = document.getElementById('add-task');
const taskList = document.getElementById('task-list');

// Add new task
addTaskButton.addEventListener('click', () => {
    const taskText = taskInput.value;

    if (taskText.trim() !== '') {
        const taskItem = document.createElement('li');
        taskItem.innerHTML = `
            <input type="checkbox" class="mark-complete">
            <span class="task">${taskText}</span>
            <button class="delete-task">Delete</button>
        `;

        // Append new task to the list
        taskList.appendChild(taskItem);

        // Clear the input field
        taskInput.value = '';

        // Add delete functionality
        taskItem.querySelector('.delete-task').addEventListener('click', () => {
            taskItem.remove();
        });

        // Add mark complete functionality
        taskItem.querySelector('.mark-complete').addEventListener('change', (event) => {
            if (event.target.checked) {
                taskItem.classList.add('completed');
            } else {
                taskItem.classList.remove('completed');
            }
        });
    }
});
