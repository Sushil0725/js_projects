import tkinter as tk
from tkinter import ttk

def convert_temperature():
    try:
        temp = float(entry_temp.get())
        from_unit = combo_from.get()
        to_unit = combo_to.get()

        if from_unit == 'Celsius':
            if to_unit == 'Fahrenheit':
                converted_temp = (temp * 9/5) + 32
            elif to_unit == 'Kelvin':
                converted_temp = temp + 273.15
            else:
                converted_temp = temp

        elif from_unit == 'Fahrenheit':
            if to_unit == 'Celsius':
                converted_temp = (temp - 32) * 5/9
            elif to_unit == 'Kelvin':
                converted_temp = (temp - 32) * 5/9 + 273.15
            else:
                converted_temp = temp

        elif from_unit == 'Kelvin':
            if to_unit == 'Celsius':
                converted_temp = temp - 273.15
            elif to_unit == 'Fahrenheit':
                converted_temp = (temp - 273.15) * 9/5 + 32
            else:
                converted_temp = temp

        label_result.config(text=f"Converted Temperature: {converted_temp:.2f} {to_unit}")
    except ValueError:
        label_result.config(text="Please enter a valid number.")

# Create main window
root = tk.Tk()
root.title("Temperature Converter")

# Create frames
frame_input = ttk.Frame(root, padding="10")
frame_input.grid(row=0, column=0, sticky=(tk.W, tk.E))

frame_output = ttk.Frame(root, padding="10")
frame_output.grid(row=1, column=0, sticky=(tk.W, tk.E))

# Input temperature
label_temp = ttk.Label(frame_input, text="Enter Temperature:")
label_temp.grid(row=0, column=0, sticky=tk.W)

entry_temp = ttk.Entry(frame_input, width=10)
entry_temp.grid(row=0, column=1, sticky=(tk.W, tk.E))

# From Unit
label_from = ttk.Label(frame_input, text="From:")
label_from.grid(row=1, column=0, sticky=tk.W)

combo_from = ttk.Combobox(frame_input, values=["Celsius", "Fahrenheit", "Kelvin"], state="readonly")
combo_from.grid(row=1, column=1, sticky=(tk.W, tk.E))
combo_from.current(0)

# To Unit
label_to = ttk.Label(frame_input, text="To:")
label_to.grid(row=2, column=0, sticky=tk.W)

combo_to = ttk.Combobox(frame_input, values=["Celsius", "Fahrenheit", "Kelvin"], state="readonly")
combo_to.grid(row=2, column=1, sticky=(tk.W, tk.E))
combo_to.current(1)

# Convert Button
button_convert = ttk.Button(frame_input, text="Convert", command=convert_temperature)
button_convert.grid(row=3, columnspan=2)

# Output Result
label_result = ttk.Label(frame_output, text="Converted Temperature: ")
label_result.grid(row=0, column=0, sticky=(tk.W, tk.E))

# Start the GUI event loop
root.mainloop()
