let countdown;
let countdownTime;

const minutesInput = document.getElementById('minutes');
const secondsInput = document.getElementById('seconds');
const display = document.getElementById('countdown-display');
const startButton = document.getElementById('start');
const resetButton = document.getElementById('reset');
const alarmSound = document.getElementById('alarm-sound');

startButton.addEventListener('click', startCountdown);
resetButton.addEventListener('click', resetCountdown);

function startCountdown() {
    const minutes = parseInt(minutesInput.value) || 0;
    const seconds = parseInt(secondsInput.value) || 0;
    countdownTime = (minutes * 60) + seconds;

    if (countdownTime > 0) {
        displayCountdown();
        countdown = setInterval(displayCountdown, 1000);
    }
}

function displayCountdown() {
    const minutes = Math.floor(countdownTime / 60);
    const seconds = countdownTime % 60;

    display.textContent = `${minutes < 10 ? '0' : ''}${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    
    if (countdownTime === 0) {
        clearInterval(countdown);
        display.classList.add('finished');
        alarmSound.play();
    } else {
        countdownTime--;
    }
}

function resetCountdown() {
    clearInterval(countdown);
    countdownTime = 0;
    display.textContent = '00:00';
    display.classList.remove('finished');
    minutesInput.value = '';
    secondsInput.value = '';
}
