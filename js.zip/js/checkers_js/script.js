// script.js

const board = document.getElementById("board");
const winnerDisplay = document.getElementById("winner");
let currentPlayer = "red";
let pieces = [];
let selectedPiece = null; // Track the selected piece

// Initialize board and pieces
function initBoard() {
  board.innerHTML = ""; // Clear board
  pieces = [];

  // Set up squares and pieces
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const square = document.createElement("div");
      square.classList.add("square");
      square.dataset.row = row;
      square.dataset.col = col;

      // Add alternating colors
      if ((row + col) % 2 === 0) {
        square.classList.add("light");
      } else {
        square.classList.add("dark");

        // Add pieces to the board
        if (row < 3) {
          addPiece(square, "black");
        } else if (row > 4) {
          addPiece(square, "red");
        }
      }
      square.addEventListener("click", onSquareClick); // Add click event to each square
      board.appendChild(square);
    }
  }
}

function addPiece(square, color) {
  const piece = document.createElement("div");
  piece.classList.add("piece", color);
  piece.addEventListener("click", onPieceClick); // Click event to select the piece
  square.appendChild(piece);
  pieces.push({ square, color });
}

// Function for selecting a piece
function onPieceClick(event) {
  event.stopPropagation();
  const piece = event.target;

  // Select the piece if it's the current player's turn
  if (piece.classList.contains(currentPlayer)) {
    selectedPiece = piece;
    highlightPiece(selectedPiece);
  }
}

// Function for moving a piece on square click
function onSquareClick(event) {
  const targetSquare = event.target.closest(".square");

  if (selectedPiece && targetSquare && !targetSquare.querySelector(".piece")) {
    const startSquare = selectedPiece.parentNode;
    const move = validateMove(startSquare, targetSquare);

    if (move.isValid) {
      targetSquare.appendChild(selectedPiece);

      // Capture opponent's piece if it's a jump
      if (move.isJump) {
        capturePiece(move.capturedSquare);
      }

      // Reset selection and switch turns
      selectedPiece = null;
      clearHighlights();
      currentPlayer = currentPlayer === "red" ? "black" : "red";

      // Check for a winner after each move
      checkForWinner();
    }
  }
}

// Highlight the selected piece
function highlightPiece(piece) {
  clearHighlights();
  piece.classList.add("selected");
}

// Clear the highlight of the selected piece
function clearHighlights() {
  document.querySelectorAll(".selected").forEach((el) => el.classList.remove("selected"));
}

// Validating moves based on Checkers rules
function validateMove(startSquare, targetSquare) {
  const startRow = parseInt(startSquare.dataset.row);
  const startCol = parseInt(startSquare.dataset.col);
  const targetRow = parseInt(targetSquare.dataset.row);
  const targetCol = parseInt(targetSquare.dataset.col);

  const direction = currentPlayer === "red" ? -1 : 1;
  const rowDiff = targetRow - startRow;
  const colDiff = Math.abs(targetCol - startCol);

  if (rowDiff === direction && colDiff === 1) {
    return { isValid: true, isJump: false };
  }

  if (rowDiff === 2 * direction && colDiff === 2) {
    const middleRow = (startRow + targetRow) / 2;
    const middleCol = (startCol + targetCol) / 2;
    const middleSquare = getSquare(middleRow, middleCol);
    const middlePiece = middleSquare.querySelector(".piece");

    if (middlePiece && middlePiece.classList.contains(opponentColor())) {
      return { isValid: true, isJump: true, capturedSquare: middleSquare };
    }
  }

  return { isValid: false };
}

function capturePiece(square) {
  square.innerHTML = "";
}

function getSquare(row, col) {
  return document.querySelector(`.square[data-row="${row}"][data-col="${col}"]`);
}

function opponentColor() {
  return currentPlayer === "red" ? "black" : "red";
}

function checkForWinner() {
  const redPieces = pieces.filter((piece) => piece.color === "red" && piece.square.childElementCount > 0);
  const blackPieces = pieces.filter((piece) => piece.color === "black" && piece.square.childElementCount > 0);

  if (redPieces.length === 0) {
    winnerDisplay.textContent = "Black Wins!";
  } else if (blackPieces.length === 0) {
    winnerDisplay.textContent = "Red Wins!";
  }
}

initBoard();
