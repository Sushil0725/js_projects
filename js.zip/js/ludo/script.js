// Create a 15x15 grid for the board
const board = document.getElementById("board");

// Define player homes and piece starting positions
const playerHomes = {
    red: [33, 34, 48, 49],       // Red pieces' home cells
    green: [42, 43, 57, 58],     // Green pieces' home cells
    blue: [168, 169, 183, 184],  // Blue pieces' home cells
    yellow: [177, 178, 192, 193] // Yellow pieces' home cells
};

// Function to create a piece and add it to a specific cell
function createPiece(color) {
    const piece = document.createElement("div");
    piece.classList.add("piece");
    piece.style.backgroundColor = color;
    return piece;
}

// Create the board grid and add pieces to initial positions
for (let i = 0; i < 15; i++) {
    for (let j = 0; j < 15; j++) {
        const cell = document.createElement("div");
        cell.classList.add("cell");
        const index = i * 15 + j + 1; // Calculate the cell index (1-based)
        cell.innerText = index;

        // Color each player's area as specified
        if ([1, 2, 3, 4, 5, 6, 21, 36, 51, 66, 16, 31, 46, 61, 76, 77, 78, 79, 80, 81, 92, 107, 108, 109, 110, 111, 112, 123].includes(index)) {
            cell.style.backgroundColor = "red"; 
        } else if ([10, 11, 12, 13, 14, 15, 30, 45, 60, 75, 90, 25, 40, 55, 70, 85, 86, 87, 88, 89, 90, 24, 23, 38, 53, 68, 83, 98, 37].includes(index)) {
            cell.style.backgroundColor = "green";
        } else if ([136, 137, 138, 139, 140, 141, 151, 166, 181, 196, 211, 212, 213, 214, 215, 216, 201, 186, 171, 156, 202, 203, 188, 173, 158, 143, 128].includes(index)) {
            cell.style.backgroundColor = "blue";
        } else if ([145, 146, 147, 148, 149, 150, 160, 165, 175, 180, 190, 195, 205, 210, 220, 221, 222, 223, 224, 225, 114, 115, 116, 117, 118, 119, 134, 103].includes(index)) {
            cell.style.backgroundColor = "yellow";
        } else if ([97, 99, 127, 129, 113].includes(index)) {
            cell.style.backgroundColor = "black";
        }

        // Place pieces in each player's home positions
        if (playerHomes.red.includes(index)) {
            cell.appendChild(createPiece("red"));
        } else if (playerHomes.green.includes(index)) {
            cell.appendChild(createPiece("green"));
        } else if (playerHomes.blue.includes(index)) {
            cell.appendChild(createPiece("blue"));
        } else if (playerHomes.yellow.includes(index)) {
            cell.appendChild(createPiece("yellow"));
        }

        board.appendChild(cell); // Append cell to the board
    }
}
document.getElementById("dice").addEventListener("click", () => {
    const roll = Math.floor(Math.random() * 6) + 1; // Generate random number 1-6
    document.getElementById("dice").textContent = roll; // Display the number
});
const players = ["Red", "Green", "Yellow", "Blue"];
let currentPlayerIndex = 0;

// Function to update the display board for the current player's turn
function updateTurnDisplay() {
    const currentPlayer = players[currentPlayerIndex];
    document.getElementById("display-board").textContent = `${currentPlayer}'s Turn`;
    document.getElementById("display-board").style.backgroundColor = currentPlayer.toLowerCase();
}

// Function to change turns after each dice roll
document.getElementById("dice").addEventListener("click", () => {
    const roll = Math.floor(Math.random() * 6) + 1;
    document.getElementById("dice").textContent = roll;
    
    // Move to the next player
    currentPlayerIndex = (currentPlayerIndex + 1) % players.length;
    updateTurnDisplay();
});

// Initialize the display board for the first player's turn
updateTurnDisplay();

