const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let player = { x: 0, y: canvas.height - 20, width: 20, height: 20, color: 'blue', isJumping: false, velocity: 0, gravity: 0.5, baseY: canvas.height - 20 };
let obstacle = { x: canvas.width, y: canvas.height - 20, width: 20, height: 20, color: 'red', speed: 2 };
let score = 0;

function draw(obj) {
    ctx.fillStyle = obj.color;
    ctx.fillRect(obj.x, obj.y, obj.width, obj.height);
}

function jump() {
    if (!player.isJumping) {
        player.isJumping = true;
        player.velocity = -10;
    }
}

function checkCollision() {
    return player.x < obstacle.x + obstacle.width &&
           player.x + player.width > obstacle.x &&
           player.y < obstacle.y + obstacle.height &&
           player.y + player.height > obstacle.y;
}

function updateScore() {
    document.getElementById('scoreboard').innerText = `Score: ${score}`;
}

function resetGame() {
    player = { x: 0, y: canvas.height - 20, width: 20, height: 20, color: 'blue', isJumping: false, velocity: 0, gravity: 0.5, baseY: canvas.height - 20 };
    obstacle = { x: canvas.width, y: canvas.height - 40, width: 20, height: 20, color: 'red', speed: 2 };
    score = 0;
    updateScore();
    document.getElementById('replayButton').style.display = 'none';
    update();
}

function update() {
    if (player.isJumping) {
        player.y += player.velocity;
        player.velocity += player.gravity;
        if (player.y >= player.baseY) {
            player.y = player.baseY;
            player.isJumping = false;
            player.velocity = 0;
        }
    }

    obstacle.x -= obstacle.speed;
    if (obstacle.x + obstacle.width < 0) {
        obstacle.x = canvas.width;
        score++; // Increase score when obstacle moves off-screen
        updateScore();
    }

    if (checkCollision()) {
        document.getElementById('replayButton').style.display = 'block'; // Show replay button
        return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    draw(player);
    draw(obstacle);
    requestAnimationFrame(update);
}

document.getElementById('replayButton').addEventListener('click', resetGame);

window.addEventListener('keydown', (event) => {
    if (event.key === ' ') {
        jump();
    }
});

update();
 