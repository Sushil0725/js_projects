function sendEmail() {
    const to = document.getElementById('to').value;
    const from = document.getElementById('from').value;
    const subject = document.getElementById('subject').value;
    const message = document.getElementById('message').value;

    if (to && from && subject && message) {
        alert(`Email sent to: ${to}\nFrom: ${from}\nSubject: ${subject}\nMessage: ${message}`);
        // Here you would typically use an API to send the email
    } else {
        alert('Please fill in all fields.');
    }
}

function closeForm() {
    document.getElementById('emailForm').reset();
    alert('Form closed');
}
