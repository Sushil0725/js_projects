const gameArea = document.getElementById("gameArea");
const scoreDisplay = document.getElementById("score");
const startButton = document.getElementById("startButton");

let score = 0;
let gameInterval;
let balloonInterval;

// Start the game
startButton.addEventListener("click", startGame);

function startGame() {
    score = 0;
    scoreDisplay.innerText = score;
    startButton.disabled = true;

    // Create new balloons every second
    balloonInterval = setInterval(createBalloon, 1000);

    // End the game after 30 seconds
    gameInterval = setTimeout(endGame, 30000);
}

// Create a new balloon with random position and speed
function createBalloon() {
    const balloon = document.createElement("div");
    balloon.classList.add("balloon");

    // Randomize balloon position and speed
    balloon.style.left = `${Math.random() * (gameArea.offsetWidth - 40)}px`;
    const riseSpeed = Math.random() * 3 + 2;

    // Click event to pop the balloon
    balloon.addEventListener("click", function() {
        score++;
        scoreDisplay.innerText = score;
        balloon.remove(); // Remove balloon on click
    });

    gameArea.appendChild(balloon);

    // Animate the balloon rising
    let position = 0;
    const balloonMove = setInterval(() => {
        position += riseSpeed;
        balloon.style.bottom = `${position}px`;

        // Remove balloon if it goes off-screen
        if (position > gameArea.offsetHeight) {
            balloon.remove();
            clearInterval(balloonMove);
        }
    }, 20);
}

// End the game
function endGame() {
    clearInterval(balloonInterval);
    startButton.disabled = false;
    alert(`Game over! Your final score is: ${score}`);
}
