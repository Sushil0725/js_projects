const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 600;
canvas.height = 400;

// Game Variables
let bird = {
    x: 50,
    y: 150,
    radius: 15,
    velocity: 0,
    gravity: 0.09,
    jump: -3
};

let pipes = [];
let frame = 0;
let score = 0;
const pipeWidth = 40;
const pipeGap = 150;
const pipeSpeed = 2;
const maxPipeHeight = canvas.height - pipeGap - 50;
let gameOver = false;

// Draw the Bird
function drawBird() {
    ctx.beginPath();
    ctx.arc(bird.x, bird.y, bird.radius, 0, 2 * Math.PI);
    ctx.fillStyle = "yellow";
    ctx.fill();
    ctx.closePath();
}

// Draw Pipes
function drawPipes() {
    pipes.forEach(pipe => {
        ctx.fillStyle = "green";
        // Top Pipe
        ctx.fillRect(pipe.x, 0, pipeWidth, pipe.topHeight);
        // Bottom Pipe
        ctx.fillRect(pipe.x, canvas.height - pipe.bottomHeight, pipeWidth, pipe.bottomHeight);
    });
}

// Update Pipes and Add New Pipes
function updatePipes() {
    if (frame % 90 === 0) {
        const topHeight = Math.floor(Math.random() * maxPipeHeight) + 20;
        const bottomHeight = canvas.height - topHeight - pipeGap;
        pipes.push({ x: canvas.width, topHeight, bottomHeight });
    }

    pipes.forEach(pipe => {
        pipe.x -= pipeSpeed;

        // Check for collisions
        if (
            bird.x + bird.radius > pipe.x &&
            bird.x - bird.radius < pipe.x + pipeWidth &&
            (bird.y - bird.radius < pipe.topHeight ||
            bird.y + bird.radius > canvas.height - pipe.bottomHeight)
        ) {
            gameOver = true;
        }

        // Remove pipes that go off screen
        if (pipe.x + pipeWidth < 0) {
            pipes.shift();
            score++;  // Increment score when the pipe passes
        }
    });
}

// Draw Score
function drawScore() {
    document.getElementById("score").innerText = `Score: ${score}`;
}

// Game Over
function showGameOver() {
    ctx.font = "48px Arial";
    ctx.fillStyle = "red";
    ctx.fillText("Game Over", canvas.width / 4, canvas.height / 2);
}

// Update Bird Position
function updateBird() {
    bird.velocity += bird.gravity;
    bird.y += bird.velocity;

    // Collision with ground or top
    if (bird.y + bird.radius >= canvas.height || bird.y - bird.radius <= 0) {
        gameOver = true;
    }
}

// Game Loop
function gameLoop() {
    if (!gameOver) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        drawBird();
        drawPipes();
        drawScore();

        updateBird();
        updatePipes();

        frame++;
        requestAnimationFrame(gameLoop);
    } else {
        showGameOver();
    }
}

// Jump the Bird
document.addEventListener("click", function() {
    bird.velocity = bird.jump;
});

// Start the Game
gameLoop();
 