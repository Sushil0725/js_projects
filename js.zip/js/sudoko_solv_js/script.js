// Initialize the board
const board = document.getElementById("board");
const cells = [];
const size = 9;

// Create 9x9 grid of input cells
for (let i = 0; i < size * size; i++) {
    const input = document.createElement("input");
    input.type = "text";
    input.maxLength = 1;
    input.classList.add("cell");
    board.appendChild(input);
    cells.push(input);
}

// "Solve" button event listener
document.getElementById("solveButton").addEventListener("click", solveSudoku);

// Parse input grid into 2D array for solving
function getGrid() {
    const grid = [];
    for (let r = 0; r < size; r++) {
        grid[r] = [];
        for (let c = 0; c < size; c++) {
            const value = cells[r * size + c].value;
            grid[r][c] = value ? parseInt(value) : 0;
        }
    }
    return grid;
}

// Populate the board from a solved grid
function setGrid(grid) {
    for (let r = 0; r < size; r++) {
        for (let c = 0; c < size; c++) {
            cells[r * size + c].value = grid[r][c] === 0 ? "" : grid[r][c];
        }
    }
}

// Check if placing a number at (row, col) is valid
function isValid(grid, row, col, num) {
    for (let i = 0; i < size; i++) {
        if (grid[row][i] === num || grid[i][col] === num ||
            grid[3 * Math.floor(row / 3) + Math.floor(i / 3)][3 * Math.floor(col / 3) + i % 3] === num) {
            return false;
        }
    }
    return true;
}

// Backtracking solver function
function solve(grid) {
    for (let row = 0; row < size; row++) {
        for (let col = 0; col < size; col++) {
            if (grid[row][col] === 0) {
                for (let num = 1; num <= 9; num++) {
                    if (isValid(grid, row, col, num)) {
                        grid[row][col] = num;
                        if (solve(grid)) return true;
                        grid[row][col] = 0;
                    }
                }
                return false;
            }
        }
    }
    return true;
}

// Solve and display the board
function solveSudoku() {
    const grid = getGrid();
    if (solve(grid)) {
        setGrid(grid);
    } else {
        alert("No solution found for this puzzle!");
    }
}
